
breederEBV <- function(df, trait, id_col = "ID", ebv_col = "EBV", rel_col = "REL") {
  stopifnot(is.data.frame(df))
  stopifnot(all(c(id_col, ebv_col, rel_col) %in% names(df)))
  
  obj <- list(
    trait = trait,
    data = df[, c(id_col, ebv_col, rel_col), drop = FALSE]
  )
  
  class(obj) <- "breederEBV"
  return(obj)
}


print.breederEBV <- function(x, ...) {
  cat("EBV Object for trait:", x$trait, "\n")
  cat("Animals:", nrow(x$data), "\n")
  cat("EBV range:", range(x$data[[2]], na.rm = TRUE), "\n")
  invisible(x)
}

summary.breederEBV <- function(object, ...) {
  ebv <- object$data[[2]]
  rel <- object$data[[3]]
  s <- list(
    trait = object$trait,
    mean = mean(ebv, na.rm = TRUE),
    sd   = sd(ebv, na.rm = TRUE),
    min  = min(ebv, na.rm = TRUE),
    max  = max(ebv, na.rm = TRUE),
    mean_rel = mean(rel, na.rm = TRUE)
  )
  class(s) <- "summary.breederEBV"
  return(s)
}

print.summary.breederEBV <- function(x, ...) {
  cat("Summary of EBV for", x$trait, "\n")
  cat("Mean:", x$mean, " SD:", x$sd, "\n")
  cat("Min:", x$min, " Max:", x$max, "\n")
  cat("Mean REL:", x$mean_rel, "\n")
  invisible(x)
}

plot.breederEBV <- function(x, ...) {
  ebv <- x$data[[2]]
  hist(ebv, breaks = 30, freq = FALSE,
       main = paste("EBV distribution for", x$trait),
       xlab = "EBV")
  lines(density(ebv), lwd = 2)
}

