#' Summary method for herd objects
#'
#' @param object A \code{"herd"} object.
#' @param ... Additional arguments.
#'
#' @return Summary statistics for EBV values.
#' @export
summary.herd <- function(object, ...) {
  data <- object$animals$ebv
  
  list(
    herd_id = object$id,
    count = length(data),
    mean_ebv = mean(data),
    sd_ebv = sd(data)
  )
}


#' Plot EBV distribution for a herd
#'
#' @param x A \code{"herd"} object.
#' @param ... Additional args.
#'
#' @return A ggplot2 object.
#' @export
plot_animals.herd <- function(x, ...) {
  df <- x$animals
  ggplot2::ggplot(df, ggplot2::aes(x = ebv)) +
    ggplot2::geom_histogram(bins = 20) +
    ggplot2::labs(title = paste("EBV Distribution - Herd", x$id))
}

