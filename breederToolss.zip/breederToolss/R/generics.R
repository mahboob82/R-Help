#' Plot method generic
#'
#' @export
plot_animals <- function(x, ...) {
  UseMethod("plot_animals")
}

