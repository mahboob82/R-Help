#' Create an Animal Object
#'
#' Constructor function for an S3 object of class \code{"animal"}.
#'
#' @param name Character string; the name of the animal.
#' @param breed Character string; breed identifier.
#' @param ebv Numeric value; estimated breeding value.
#'
#' @return An object of class \code{"animal"}.
#' @export
#'
#' @examples
#' bull <- new_animal("Alpha", "Holstein", 115)
#' bull
new_animal <- function(name, breed, ebv) {
  structure(
    list(
      name = name,
      breed = breed,
      ebv = ebv
    ),
    class = "animal"
  )
}
