#' Create a Herd Object
#'
#' Constructor for an S3 object of class \code{"herd"}.
#'
#' @param animals A data.frame containing columns name, breed, ebv.
#' @param id Character string; herd ID.
#'
#' @return An object of class \code{"herd"}.
#' @export
#'
#' @examples
#' df <- data.frame(
#'   name = c("Alpha", "Bravo"),
#'   breed = c("Holstein", "Holstein"),
#'   ebv = c(115, 98)
#' )
#' h1 <- new_herd(df, "Farm01")
new_herd <- function(animals, id) {
  stopifnot(is.data.frame(animals))
  stopifnot(all(c("name", "breed", "ebv") %in% names(animals)))
  
  structure(
    list(
      id = id,
      animals = animals
    ),
    class = "herd"
  )
}
