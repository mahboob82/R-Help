#' Print an Animal Object
#'
#' S3 print method for objects of class \code{"animal"}.
#'
#' @param x An object of class \code{"animal"}.
#' @param ... Additional arguments (unused).
#'
#' @return Printed output to the console.
#' @export
print.animal <- function(x, ...) {
  cat("Animal:", x$name, "\nBreed:", x$breed, "\nEBV:", x$ebv, "\n")
}


#' Summary for an Animal Object
#'
#' S3 summary method for \code{"animal"} objects.
#'
#' @param object An object of class \code{"animal"}.
#' @param ... Additional arguments (unused).
#'
#' @return A list containing elements of the animal object and descriptor text.
#' @export
summary.animal <- function(object, ...) {
  list(
    name = object$name,
    breed = object$breed,
    ebv = object$ebv,
    info = "This is a summary of an S3 animal object."
  )
}
